Microsoft Azure CLI 'aksbpa' Extension
==========================================

This package is for the 'aksbpa' extension.
i.e. 'az aksbpa'